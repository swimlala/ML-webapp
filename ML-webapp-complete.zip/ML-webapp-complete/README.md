# Intro ML Code

Some helper code that can be useful for creating a machine learning project.
